//velocidad de 4 Mhz
//Usar decoder 74ls48 para catodo comun
#include <multiplex_ejemplo.h>
#define unidades  PIN_E1
#define decenas   PIN_E2
int1 a=0;//unid bandera
int1 b=1;//dece bandera
int8 i=0;//variable contadora
int8 dec=0;//variable que almacena las decenas
int8 unid=0;//variable que almacena las unidades
int8 disp[10]={63,6,91,79,102,109,125,7,127,103};//0,1,2,3,4,5,6,7,8,9

#INT_TIMER0
void  TIMER0_isr(void) 
{
   a=!a;//se usan las banderas para la conmutacion de los transistores aprocechando el timer 0 de 1mS
   b=!b;
   if(a==1 && b==0){
   output_toggle(decenas);
   output_toggle(unidades);
   output_d(disp[unid]);
   }
   if(a==0 && b==1){
   output_toggle(unidades);
   output_toggle(decenas);
   output_d(disp[dec]);
   }
}

#INT_EXT
void  EXT_isr(void) 
{
i++;
unid=i;
dec=0;
  for(unid;unid>=10;dec++){ // separamos las decenas de las unidades
   unid=unid-10;
   }
}

void main()
{
   setup_timer_0(RTCC_INTERNAL|RTCC_DIV_4|RTCC_8_bit);      //1.0 ms overflow con DIV_4 1Khz de frecuencia
   enable_interrupts(INT_TIMER0);
   enable_interrupts(INT_EXT);
   enable_interrupts(GLOBAL);
   output_high(decenas);//iniciamos con las decenas encendidas
   output_low(unidades);//iniciamos con las unidades apagadas
   while(TRUE)
   {
    //TODO: User Code
   }

}
/*
TABLA 7SEG DECIMAL
   0- 63
   1- 6
   2- 91
   3- 79
   4- 102
   5- 109
   6- 125
   7- 7
   8- 127
   9- 103
*/
