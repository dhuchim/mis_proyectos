//Velocidad de 2MHz
//Ejemplo de como funciona la multiplexacin en un tiempo mas lento para que el 
//ojo humano pueda verlo.

#include <multiplex_500ms.h>
#define unidades  PIN_E1
#define decenas   PIN_E2
int1 a=0;//
int1 b=1;//
int8 i=0;//variable contadora
int8 dec=0;//variable que almacena las decenas
int8 unid=0;//variable que almacena las unidades
int8 disp[10]={63,6,91,79,102,109,125,7,127,103};//0,1,2,3,4,5,6,7,8,9

#INT_TIMER1
void  TIMER1_isr(void) 
{
   a=!a;
   b=!b;
   if(a==1 && b==0){
   output_toggle(decenas);
   output_toggle(unidades);
   output_d(disp[unid]);
   }
   if(a==0 && b==1){
   output_toggle(unidades);
   output_toggle(decenas);
   output_d(disp[dec]);
   }
}

#INT_EXT
void  EXT_isr(void) 
{
i++;
unid=i;
dec=0;
  for(unid;unid>=10;dec++){
   unid=unid-10;
   }
}

void main()
{
   setup_timer_1(T1_INTERNAL|T1_DIV_BY_1);      //524 ms overflow con T1_DIV_BY_4
   enable_interrupts(INT_TIMER1);
   enable_interrupts(INT_EXT);
   enable_interrupts(GLOBAL);
   output_high(decenas);
   output_low(unidades);
   while(TRUE)
   {

   }
   
 }
