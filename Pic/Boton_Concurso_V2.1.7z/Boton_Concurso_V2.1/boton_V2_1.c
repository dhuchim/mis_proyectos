//Velocidad de 4Mhz
//Incluye programacion de 7 segmentos
#include <boton_V2_1.h>
#define cas1 PIN_A0
#define cas2 PIN_A1
#define led1 PIN_A2
#define led2 PIN_A3
#define bzzr PIN_E0
int1 buzzer=0;
int32 millis=0;
int32 inicio=0;
int8 cast=0;

#INT_TIMER0
void  TIMER0_isr(void) 
{

   if (buzzer==1 && millis-inicio <= 5501){//duracion total del conteo incluyendo 1mS adicional como candadito
      
      if (millis-inicio >=0 && millis-inicio <=1000){//4
      output_d(102);
         if (millis-inicio <150){//intermitencia del buzzer
         output_high(bzzr);
         }
         else{
         output_low(bzzr);
         }
         if(millis-inicio >600){
         output_low(cas1);
         output_low(cas2);
         cast=0;
         }
      }
      if (millis-inicio >1000 && millis-inicio <=2000){//3
      output_d(79);
      
         if (millis-inicio <1150){//intermitencia del buzzer
            output_high(bzzr);
            }
        else{
            output_low(bzzr);
            }
      }
      if (millis-inicio >2000 && millis-inicio <=3000){//2
      output_d(91);
         if (millis-inicio <2150){//intermitencia del buzzer
         output_high(bzzr);
         }
         else{
         output_low(bzzr);
         }}
      if (millis-inicio >3000 && millis-inicio <=4000){//1
      output_d(6);
         if (millis-inicio <3150){//intermitencia del buzzer
         output_high(bzzr);
         }
        else{
         output_low(bzzr);
         }}
      if (millis-inicio >4000 && millis-inicio <5000){//0
      output_d(63);
      output_low(led1);//apagamos led1
      output_low(led2);//apagamos led2
      output_low(CAS1); //apagamos castigo1
      output_low(CAS2);//apagamos castigo2
      output_high(bzzr);//activamos el buzzer
      }
      if (millis-inicio >= 5500){//VACIO
      clear_interrupt(INT_EXT); //limpiamos la banderas
      clear_interrupt(INT_EXT1);//limpiamos la bandera
      enable_interrupts(INT_EXT); //nuevamente habilitamos la interrupcion
      enable_interrupts(INT_EXT1); //nuevamente habilitamosla interrupcion
      output_d(0);
      buzzer=0;
      output_low(bzzr);//apagamos buzzer
      }
   }
      millis++;//aumentamos la variable millis
}

#INT_EXT//----JUGADOR 1----//
void  EXT_isr(void) 
{
disable_interrupts(INT_EXT1);//deshabilidamos la interrupcion
disable_interrupts(INT_EXT);//deshabilidamos la interrupcion
output_high(led1);//encendemos la notificacion 1
output_high(cas1);
inicio=millis;//tomamos el valor actual del contador de segundos
buzzer=1;//activamos la bandera del buzzer
cast=1;//seleccionamos el castigo 
}

#INT_EXT1 //----JUGADOR 2----//
void  EXT1_isr(void) 
{
disable_interrupts(INT_EXT);//deshabilidamos la interrupcion
disable_interrupts(INT_EXT1);//deshabilidamos la interrupcion
output_high(led2);//encendemos la notificacion 1
output_high(cas2);
inicio=millis;//tomamos el valor actual del contadorde segundos
buzzer=1;//activamos la bandera del buzzer
cast=2;//seleccionamos el castigo 
}

#INT_EXT2  //------RESET----//
void  EXT2_isr(void) 
{
clear_interrupt(INT_EXT); //limpiamos la banderas
clear_interrupt(INT_EXT1);//limpiamos la bandera
enable_interrupts(INT_EXT); //nuevamente habilitamos la interrupcion
enable_interrupts(INT_EXT1); //nuevamente habilitamosla interrupcion
buzzer=0; //limpiamos la bandera del buzzer
output_d(0); //limpiamos el 7 segmentos
output_low(CAS1); //apagamos castigo1
output_low(CAS2);//apagamos castigo2
output_low(led1);//apagamos led1
output_low(led2);//apagamos led2
output_low(bzzr);//apagamos buzzer
}

void main()
{
   setup_timer_0(RTCC_INTERNAL|RTCC_DIV_4|RTCC_8_bit);      //1.0 ms overflow
   enable_interrupts(INT_TIMER0);
   enable_interrupts(INT_EXT);
   enable_interrupts(INT_EXT1);
   enable_interrupts(INT_EXT2);
   enable_interrupts(GLOBAL);
//iniciamos todo apagado
   output_low(CAS1);
   output_low(CAS2);
   output_low(led1);
   output_low(led2);
   output_low(bzzr);
  
   while(TRUE)
   {
      //TODO: User Code
   }

}
/*
TABLA 7SEG DECIMAL
   0- 63
   1- 6
   2- 91
   3- 79
   4- 102
   5- 109
   6- 125
   7- 7
   8- 127
   9- 103
*/
